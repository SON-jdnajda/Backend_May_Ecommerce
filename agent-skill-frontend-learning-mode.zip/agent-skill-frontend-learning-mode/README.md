# Agent Skill — Frontend Learning Mode

Bộ này dùng cho **Frontend**. Mục tiêu là dạy bạn tự code giao diện thay vì AI làm hết.

Phù hợp với:

- React / TypeScript / Vite
- Tailwind CSS
- Component architecture
- Data-driven rendering
- Responsive UI
- Template matching / visual QA

Cách dùng prompt:

```txt
Hướng dẫn tôi tự code từng bước, đừng làm hộ.
Bắt đầu từ bước chia layout ảnh mẫu thành React components.
```

Khi muốn AI viết mẫu đầy đủ:

```txt
fullcode mẫu để tôi đọc và học
```
