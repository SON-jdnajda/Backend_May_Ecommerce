# Frontend Architecture Reference

## Target Structure

```txt
src/
  app/
    App.tsx
  components/
    layout/
      PageContainer.tsx
    sections/
      HeroSection.tsx
      CategoryStrip.tsx
      BenefitsBar.tsx
      BestSellerSection.tsx
      PromoSection.tsx
      FooterBar.tsx
    ui/
      ProductCard.tsx
      IconBadge.tsx
      PriceText.tsx
      SectionCard.tsx
  data/
    products.ts
    categories.ts
    benefits.ts
  types/
    product.ts
    category.ts
    benefit.ts
  utils/
    formatCurrency.ts
    cn.ts
  styles/
    tokens.css
```

## Responsibility Rules

- `App.tsx` composes the page.
- `sections/` hold big page sections.
- `ui/` hold reusable pieces.
- `data/` holds static arrays.
- `types/` holds TypeScript contracts.
- `utils/` holds reusable functions.
- `styles/` holds design tokens.
