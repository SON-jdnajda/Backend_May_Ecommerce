# Frontend Maintenance Checklist

Refactor if you see:

- Product cards duplicated manually.
- Category cards duplicated manually.
- Colors repeated as hex values everywhere.
- `App.tsx` is too long.
- One component has too many responsibilities.
- Business data inside layout components.
- Any TypeScript `any` without reason.
- Unused imports.
- Mobile horizontal overflow.

Verify:

```bash
npm run build
npm run lint
```
