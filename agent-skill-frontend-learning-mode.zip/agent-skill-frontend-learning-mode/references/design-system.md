# Frontend Design System Reference

## CSS Variables

```css
:root {
  --color-bg: #fff4f7;
  --color-bg-soft: #fff8fa;
  --color-card: #ffffff;
  --color-primary: #d96b86;
  --color-primary-dark: #a93f5e;
  --color-text: #3f3134;
  --color-muted: #8b7178;
  --color-border: #efd1d9;
  --shadow-soft: 0 18px 50px rgba(184, 70, 102, 0.12);
}
```

## Rule

Teach users to replace repeated hex colors with CSS variables or Tailwind theme tokens.
