# Frontend Component Contract

## Product Type

```ts
export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  imageAlt: string;
  tag?: string;
}
```

## Category Type

```ts
export interface Category {
  id: string;
  name: string;
  image: string;
  imageAlt: string;
}
```

## Benefit Type

```ts
export interface Benefit {
  id: string;
  title: string;
  subtitle?: string;
  icon: 'shield' | 'truck' | 'leaf' | 'gift' | 'headphones' | 'star';
}
```

## Utility

```ts
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('vi-VN').format(value) + 'đ';
}
```
