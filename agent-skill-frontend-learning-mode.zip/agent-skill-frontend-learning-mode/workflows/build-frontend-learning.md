---
description: Build or refactor frontend only after user approval.
---

# Build Frontend Learning Workflow

## Step 1 — Confirm Approval

Only implement after explicit approval.

## Step 2 — Inspect

Read project structure, package scripts, styling system, and existing components.

## Step 3 — Teach First

Explain the concept and give a small task unless the user asked for fullcode.

## Step 4 — Implement If Approved

Create or update scoped frontend files only.

## Step 5 — Verify

Run build/lint. Check responsive layout.

## Step 6 — Learning Log

Update memory files with what changed and what was learned.
