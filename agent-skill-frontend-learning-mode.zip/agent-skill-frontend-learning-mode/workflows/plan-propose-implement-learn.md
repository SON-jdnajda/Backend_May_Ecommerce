---
description: Learning-first workflow: inspect, propose a learning path, teach step-by-step, review user code, implement only after explicit approval, verify, and write learning log.
---

# Plan, Propose, Learn, Review, Implement Workflow

## Phase 1 — Inspect

Run only safe read commands:

```bash
pwd
ls
cat package.json
```

Check:

- Framework / runtime
- Language and package manager
- Existing folder structure
- Existing scripts
- Existing assets/configs

Do not edit files in this phase.

## Phase 2 — Read Project Memory

Read these files if they exist:

```txt
.agent/memory/project-context.md
.agent/memory/decisions.md
.agent/memory/implementation-log.md
.agent/memory/lessons-learned.md
```

Use previous lessons and decisions when creating the learning plan.

## Phase 3 — Create Learning Proposal

Create this proposal:

```md
# Learning Implementation Proposal

## User Request

## Current Project Understanding

## Learning Goal

## Proposed Learning Path

## First Coding Task For You

## Files We May Touch Later

## Dependencies
No new dependencies unless justified.

## Risks

## Verification Plan

## Need Your Choice
Bạn muốn tự code từng bước hay muốn tôi viết fullcode mẫu để bạn đọc và học?
```

Stop after the proposal. Do not implement.

## Phase 4 — User Chooses Mode

### If user chooses `Tự code từng bước`

Teach one small part at a time:

```md
## Step X — Topic Name

### Mục tiêu
### Ý tưởng
### Code mẫu nhỏ
### Nhiệm vụ của bạn
### Cách kiểm tra
### Gửi lại cho tôi
```

Wait for the user before moving to the next large step.

### If user chooses `Viết fullcode mẫu`

Provide code, but explain:

- Where to place it.
- Why each part exists.
- What to study.
- How to test it.

### If user says `OK làm`, `Làm đi`, `Approve`, `Proceed`, `Đồng ý`, or `AI tự làm`

Implementation is allowed according to the approved plan.

## Phase 5 — Verify

Run the relevant verification commands for the stack.
Explain any failing error before fixing it.

## Phase 6 — Update Learning Memory

After implementation and verification, update:

```txt
.agent/memory/implementation-log.md
.agent/memory/lessons-learned.md
```

Update `decisions.md` only for important architecture/design decisions.
Update `project-context.md` only if stack/project structure changes.
