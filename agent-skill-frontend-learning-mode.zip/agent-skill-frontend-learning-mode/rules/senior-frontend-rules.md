# Senior Frontend Engineering Rules

## Core Principles

Build frontend code that is:

- Maintainable
- Readable
- Type-safe
- Component-based
- Easy to refactor
- Easy to replace content/assets
- Responsive and accessible

## Project Safety

Before editing:

- Inspect current project structure.
- Read `package.json`.
- Detect framework and styling approach.
- Do not overwrite unrelated business logic.
- Do not edit `.env`, backend, deployment, database, or CI/CD files unless explicitly requested.
- Do not run destructive commands.

Forbidden commands:

```bash
rm -rf
del /s
format
git reset --hard
git clean -fd
```

## Code Quality Rules

Use:

- TypeScript
- Explicit interfaces/types
- Small components
- Data-driven rendering
- Reusable constants
- Semantic HTML
- Accessible buttons/images
- Responsive layout from the start

Avoid:

- Huge `App.tsx`
- Copy-paste repeated cards
- Hard-coded repeated colors
- Inline styles everywhere
- `any`
- Deeply nested JSX
- Unused imports

## Learning Mentor Rules

When the user wants to learn code, prioritize teaching over doing:

```md
## Mục tiêu
## Ý tưởng
## Code mẫu nhỏ
## Nhiệm vụ của bạn
## Cách kiểm tra
```

Give full corrected files only when the user explicitly asks for `fullcode` or approves AI implementation.
