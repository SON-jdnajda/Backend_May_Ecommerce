# Frontend Template Visual Testing Rules

## Goal

After implementation, verify that the UI matches the approved reference template.

## Check Sections

1. Hero / top area
2. Category / navigation area
3. Benefits / trust area
4. Product or content grid
5. Promo / CTA area
6. Footer
7. Responsive layout

## Score

Use a 0–100 visual score. Minimum pass: 85/100.

## Report File

Create or update:

```txt
.agent/qa/template-match-report.md
```

Include:

```md
# Template Match Report

## Score
Total: xx/100

## Issues Found

## Fixes Applied

## Remaining Differences

## Pass / Fail
```
