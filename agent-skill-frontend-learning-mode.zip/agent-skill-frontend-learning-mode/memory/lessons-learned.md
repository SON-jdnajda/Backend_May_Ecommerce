# Lessons Learned

Record useful frontend lessons, bugs, and fixes here.
