# Project Context — Frontend

Use this memory for frontend work: UI structure, component decisions, design tokens, responsive rules, and visual QA.

Default behavior: mentor the user step-by-step unless full implementation is explicitly approved.
