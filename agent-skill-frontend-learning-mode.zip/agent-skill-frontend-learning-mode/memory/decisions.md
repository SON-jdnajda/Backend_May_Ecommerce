# Decisions

Record important frontend architecture or design decisions here.
